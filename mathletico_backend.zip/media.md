![docs-django-adminlte-thumb](https://github.com/user-attachments/assets/4d5f6b17-3b80-469b-ade7-2b8e318f829d)
